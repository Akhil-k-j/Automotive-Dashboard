#include"header.h"

extern int data_flag;
extern CAN2 r1;
extern int remote_flag;
void CAN2_rx_Handler() __irq
{
	r1.id=C2RID;
	r1.dlc=(C2RFS>>16)&0xF; //Extract dlc;
	r1.rtr=(C2RFS>>30)&1;
	if(r1.rtr==0)
	{
		r1.byteA=C2RDA;
		r1.byteB=C2RDB;
		data_flag=1;
	}
	else
	remote_flag=1;
	C2CMR=(1<<2);  //release rx buff
	VICVectAddr=0; //to stop isr execution
}

void en_can1_interrupt(void)
{
	C2IER=1;
}
void config_vic_for_can2(void)
{
		VICIntSelect=0;
		VICVectCntl2=27|(1<<5);
		VICVectAddr2=(u32)CAN2_rx_Handler;
		VICIntEnable=(1<<27);  //Enable can1 rx interrupt
}






