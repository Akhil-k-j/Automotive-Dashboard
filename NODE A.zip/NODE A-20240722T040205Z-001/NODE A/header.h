#include<LPC21xx.h>

typedef unsigned int u32;
typedef unsigned short u16;
typedef unsigned char u8;
typedef signed char s8;
typedef signed  int s32;
typedef signed short s16;
typedef signed char s8;


void delay_ms(unsigned int);
void delay_s(unsigned int);


void lcd_init(void);
void lcd_cmd(unsigned char);
void lcd_data(unsigned char);
void lcd_string(char *);
void lcd_integer(int);
void lcd_float(float);
void lcd_cgram(void);
void lcd_hexa(int);
void r_scroll(void);

void uart0_init(u32 );
char uart0_rx(void);
void uart0_tx(u8);
void uart0_tx_string(char *);
void uart0_tx_integer(int );
void uart0_tx_float(float x);
void uart0_rx_string(u8 *,u8);



typedef struct  CAN2_MSG
{
	u32 id;
	u32 rtr;
	u32 dlc;
	u32 byteA;
	u32 byteB;
}CAN2;

void can2_init(void);
void can2_tx(CAN2);
void can2_rx(CAN2*);
u32 adc_read(u8);
void adc_init(void);
void config_eint0(void);
void ent0_init(void);


void config_vic_for_can2(void);
void en_can1_interrupt(void);




