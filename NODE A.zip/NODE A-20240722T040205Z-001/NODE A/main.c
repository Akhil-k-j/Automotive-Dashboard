#include"header.h"	
int flag1,flag2,flag3;
int remote_flag;  //Flag is set when the remote frame is reached interrupt trigger.
int data_flag;   //Flag is set whena ny data frame received in the buffer
CAN2 r1;     //stores the remote data when any remote frame is recevied in the Buffer
#define SW1 ((IOPIN0>>14)&1)
#define SW2 ((IOPIN0>>15)&1)
#define SW3 ((IOPIN0>>16)&1)
int main()
	{
	float temp,temp_temp,vout1,vout2,temp_battery;
	int x,y;
	int battery;
	CAN2 LI,RI,HL,TX;
	en_can1_interrupt();
	config_vic_for_can2();
		
		can2_init();
	//	config_eint0();
	//	ent0_init();
		adc_init();
	//	uart0_init(9600);    //debug

		TX.id=0x123;
		TX.dlc=8;
		TX.rtr=0;
		
	LI.id=0x123;
	LI.rtr=0;
	LI.dlc=1;
	LI.byteA=0x10;
	LI.byteB=0x0;
		
	RI.id=0x123;
	RI.rtr=0;
	RI.dlc=1;
	RI.byteA=0x01;
	RI.byteB=0x0;
		
	HL.id=0x123;
	HL.rtr=0;
	HL.dlc=1;
	HL.byteA=0x11;
	HL.byteB=0x0;
	while(1)
	{	
		if(SW3==0)
		{
			while(SW3==0);
			can2_tx(RI);
		//	uart0_tx_string("Right Indicator\r\n");   // debug
		}
		if(SW1==0)
		{
			 while(SW1==0);
			can2_tx(LI);
		//	uart0_tx_string("Left indicator\r\n");   // debug
		}
		if(SW2==0)
		{
			while(SW2==0);
			can2_tx(HL);
		//	uart0_tx_string("Head light\r\n");   // debug
		}
if(remote_flag==1)	     
		{
			remote_flag=0;
			temp_temp=adc_read(1);
			vout1=(temp_temp*3.3)/1023;
			temp=(vout1-0.5)/0.01;
			temp_battery=adc_read(2);
			vout2=(temp_battery*3.3)/1023;
			battery=(vout2*30);
			x=temp;
			y=((temp-x)*10);
			battery=battery<<16;
			TX.id=r1.id;
			TX.dlc=r1.dlc;
			TX.byteB=battery;
			TX.byteB|=x<<8;
			TX.byteB|=y;
			can2_tx(TX);
//			uart0_tx_string("\r\n");
//			uart0_tx_integer((TX.byteB&0xffff0000)>>16);
//			uart0_tx_string("\r\n");
//			uart0_tx_integer((TX.byteB&0xff00)>>8);
//			uart0_tx_string("\r\n");
//			uart0_tx_integer(TX.byteB&0xff);
//			uart0_tx_string("\r\n");				
		}
	}
}

