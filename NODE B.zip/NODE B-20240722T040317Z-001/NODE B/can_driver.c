#include"header.h"

void can2_init(void)
{
	VPBDIV=1;
	PINSEL1|=0x15414000;
	C2MOD=1;
	AFMR=2;
	C2BTR=0x001C001D;
	C2MOD=0;
}


#define TCS (C2GSR &8)
void can2_tx(CAN2 V)
{
	C2TID1=V.id;
	C2TFI1=(V.dlc<<16);
	if(V.rtr==0)
	{
		C2TDA1=V.byteA;
		C2TDB1=V.byteB;
	}
	else
		C2TFI1|=(1<<30);
	C2CMR=1|(1<<5);
	while(TCS==0);
}





#define RBS (C2GSR&1)
void can2_rx(CAN2 *ptr)
{
	while(RBS==0);
	ptr->id=C2RID;
	ptr->dlc=(C2RFS>>16)&0xF;
	ptr->rtr=(C2RFS>>30)&1;
	if(ptr->rtr==0)
	{
		ptr->byteA=C2RDA;
		ptr->byteB=C2RDB;
	}
	C2CMR=(1<<2);
}
