#include"header.h"	
#define ALL_LED (7<<17)
#define HL_LED (1<<18)
#define LI_LED  (1<<19)
#define RI_LED  (1<<17)

//data to print the Battery symbol in in different level
char a[7][8]={{0xE,0x1b,0x11,0x11,0x11,0x11,0x11,0x1f},{0xE,0x1b,0x11,0x11,0x11,0x11,0x1f,0x1F},
			  {0xe,0x1b,0x11,0x11,0x11,0x1f,0x1f,0x1f},{0xe,0x1b,0x11,0x11,0x1f,0x1f,0x1f,0x1f},
	    	{0xe,0x1b,0x11,0x1f,0x1f,0x1f,0x1f,0x1f},{0xe,0x1b,0x1f,0x1f,0x1f,0x1f,0x1f,0x1f},
				{0xe,0x1f,0x1f,0x1f,0x1f,0x1f,0x1f,0x1f}};

//headlight symbol data to be loaded to the pager
char hl1[]={0x7,0x0,0x7,0x0,0x7,0x0,0x7,0x0};
char hl2[]={0x1c,0x12,0x11,0x11,0x11,0x12,0x1c,0x0};

//right and left indicator symbol to be loaded to the pager
char li[]={0x2,0x6,0xE,0x1e,0xe,0x6,0x2,0x0};
char ri[]={0x8,0xc,0xe,0xf,0xe,0xc,0x8,0x0};

//thermometer symbol to be loaded to th pager
char t[]={0x4,0xa,0xa,0xe,0xe,0x1f,0xe,0xe};


int flag;   //become 1 when the data frame receives
CAN2 m1;	  //structure varuiable to store the TX data
CAN2 R1;	   // structure varuabe to strore the remote frame data

// variable to toggle the data upon every timer interrupt
int LI_SYMBOL;	 
int RI_SYMBOL;


extern int timer_flag;   //become 1 one every interrupt trigger
extern int remote_flag;	  //trigger when remote frame received

int main()
	{
		int temp,battery;
		static int LI;
		static int RI;
		static int HL;
		can2_init();
		en_can1_interrupt();

		config_vic_for_timer1_interrupt();
		en_timer1_interrupt();


		config_vic_for_can2();
		uart0_init(9600);    //debug
		lcd_init();
		lcd_custom_init();
		IODIR0=ALL_LED;
		IOSET0=ALL_LED;
		uart0_tx_string("Test\r\n"); 
		
		R1.id=0x77;
		R1.rtr=1;
		R1.dlc=8;
		//Initinalizing the value to the Match register to trigger interrupt upon mathcing with the TC value 	
		T1MR0=250;
		T1MR1=500;
		T1MR2=750;
		T1MR3=1000;
		T1TCR=1;     
		//Finally starting the timer, This timer will never get turned off, Since we conituouesly send the remote frame every one second
	while(1)
	{
			if(flag==1)
			{
			//	uart0_tx_string("CAN recieved\r\n"); 
				flag=0;
				switch((m1.byteA)&0xFF)
				{
					case 0x11:
					{
					//	uart0_tx_string("HL\r\n");   //debug
							HL^=1;
							break;
					}
					case 0x10: 
					{
					//	uart0_tx_string("LI\r\n");   //debug
							IOSET0=(1<<17)|(1<<19);
							LI^=1;
							RI=0;	 RI_SYMBOL=0;
								break;
					}						
					case 0x01: 
					{
					//	uart0_tx_string("RI\r\n");   //debug
							IOSET0=(1<<17)|(1<<19);
							RI^=1;
							LI=0;	LI_SYMBOL=0;
								break;
					}
					case 0x00:
					{
					//	uart0_tx_string("temp\r\n");   //debug
 						temp=(m1.byteB)&0xFFFF;
						battery=(m1.byteB>>16)&0xFFFF; 
							break;
					}
					default:uart0_tx_string("wrong option\r\n");   //debug purpose
					}	
			}
			lcd_cmd(0x80);
			if(LI==1 && timer_flag)
			{
			 IOCLR0=1<<17;
			 //	lcd_cmd(0x80);
				lcd_data(2);
			//  uart0_tx_string("LI\r\n");
			}
			else
			{
				lcd_data(' ');	     //makes that index as space =>left blank
			}
			lcd_cmd(0x8F);
			if(RI==1 && timer_flag)
			{
				IOCLR0=1<<19;
			//	lcd_cmd(0x8F);
				lcd_data(3);
			//	uart0_tx_string("RI\r\n");
			}
			else
			{
				lcd_data(' ');
			}			
			if(timer_flag==0)
			{		
				IOSET0=1<<19;
				IOSET0=1<<17;
			}
			//Send the remote fram upon every 1 sec gap, since the flag is  set based on the timer interrupt
			if(remote_flag==1)
			{
				can2_tx(R1);	    //sending the remote frame
				remote_flag=0;
			}	
				if(HL)
				{
					//printing the LCD symbol
					lcd_cmd(0x87);
					lcd_data(4);
					lcd_cmd(0x88);
					lcd_data(5);
					IOCLR0=1<<18;
				}
				else
				{
					lcd_cmd(0x87);
					lcd_data(' ');
					lcd_cmd(0x88);
					lcd_data(' ');
					IOCLR0=1<<18;
					IOSET0=1<<18;
				}
				//below logic extract the exact battery symbol number to be displayed
				if(battery>90)
				battery_lcd(6);
				else if(battery>75)
					battery_lcd(5);
				else if(battery>60)
					battery_lcd(4);
				else if(battery>45)
					battery_lcd(3);
				else if(battery>30)
					battery_lcd(2);
				else if(battery>15)
					battery_lcd(1);
				else if(battery>=0)
					battery_lcd(0);
				
				//pritning battery sysmbol
				if(battery==99)
				battery=100;
				lcd_integer(battery);   //actual percentage printing
				lcd_data('%');
				
				//temperature
				lcd_cmd(0xCA);
		  		lcd_integer((temp&0xFF00)>>8);
				lcd_data('.');
			    lcd_integer(temp&0xff);
				lcd_data('C');
				lcd_cmd(0xcf);
				lcd_data(1);	  //temperature symbol printing	
		//		lcd_cmd(0x01);   not using since found the LCD is flickering.
	}
}
void battery_lcd(int x)
{
	int i=0;
	lcd_cmd(0x40);   //page 0
	for(i=0;i<8;i++)
	{
		lcd_data(a[x][i]);
	}
	lcd_cmd(0xc0);	//printing the symbol at the 0xc0 index from the pager
	lcd_data(0);
}

void lcd_custom_init(void)
{
	//Temp symbol page 1
	int i=0;
	lcd_cmd(0x48);
	for(i=0;i<8;i++)
	lcd_data(t[i]);
	
	//left indicator storing  page 2
	lcd_cmd(0x50);
	for(i=0;i<8;i++)
	lcd_data(li[i]);
	
	//right indicator   //page 3
	lcd_cmd(0x58);
	for(i=0;i<8;i++)
	lcd_data(ri[i]);
	
	//headlight      //page 4
	lcd_cmd(0x60);
	for(i=0;i<8;i++)
	lcd_data(hl1[i]);

	 //headlight   //page 5
	lcd_cmd(0x68);
	for(i=0;i<8;i++)
	lcd_data(hl2[i]);
}
