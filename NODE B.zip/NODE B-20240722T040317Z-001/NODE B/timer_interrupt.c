#include"header.h"
int timer_flag;
int remote_flag;
void timer1_interrupt(void)__irq
{
	if((T1IR&1)|(T1IR&2)|(T1IR&4))
	{
		T1IR=15;
		timer_flag^=1;
	}
	if((T1IR>>3)&1)
	{
	T1IR=15;
	remote_flag=1;
	timer_flag^=1;
	}
	VICVectAddr=0;	
}



void config_vic_for_timer1_interrupt(void)
{
	VICIntSelect=0;
	VICVectCntl1=5|(1<<5);
	VICVectAddr1=(u32)timer1_interrupt;
	VICIntEnable|=(1<<5);
}

void en_timer1_interrupt(void)
{
		T1PC=0;
		T1MCR=(1|(1<<3)|(1<<6)|(3<<9));
		T1PR=60000-1;
		T1TC=0;
		T1TCR=1;
}
